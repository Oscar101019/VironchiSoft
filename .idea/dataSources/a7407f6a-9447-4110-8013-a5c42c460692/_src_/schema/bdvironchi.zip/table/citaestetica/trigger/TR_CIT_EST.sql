CREATE TRIGGER `TR_CIT_EST`
BEFORE INSERT ON `citaestetica`
FOR EACH ROW
  BEGIN
	insert into Tabla_Citas_Inicio set Id_Mascota=New.Id_Mascota, TipoCit ='Cita Estetica',Fecha= NEW.Fecha;
END