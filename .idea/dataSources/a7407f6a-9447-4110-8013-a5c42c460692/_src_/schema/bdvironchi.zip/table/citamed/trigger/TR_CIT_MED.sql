CREATE TRIGGER TR_CIT_MED
BEFORE INSERT ON citamed
FOR EACH ROW
  BEGIN
	insert into Tabla_Citas_Inicio set Id_Mascota=New.Id_Mascota, TipoCit ='Cita Medica',Fecha= NEW.Fecha;
END;
