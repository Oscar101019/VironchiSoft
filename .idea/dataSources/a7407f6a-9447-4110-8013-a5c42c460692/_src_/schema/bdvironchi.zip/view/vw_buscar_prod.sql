CREATE VIEW `vw_buscar_prod` AS
  (SELECT
     `p`.`Nombre`              AS `Nombre`,
     `p`.`CantidadPorUnidad`   AS `CantidadPorUnidad`,
     `p`.`PrecioUnitario`      AS `PrecioUnitario`,
     `p`.`UnidadesAlmacenadas` AS `UnidadesAlmacenadas`,
     `i`.`Nombre`              AS `Inventario`,
     `i`.`ID_Inventario`       AS `ID_Inventario`
   FROM (`bdvironchi`.`producto` `p`
     JOIN `bdvironchi`.`inventario` `i` ON ((`p`.`ID_Inventario` = `i`.`ID_Inventario`))))