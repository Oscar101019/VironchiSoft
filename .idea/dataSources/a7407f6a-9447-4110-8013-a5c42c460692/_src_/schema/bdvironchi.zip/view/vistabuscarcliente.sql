CREATE VIEW vistabuscarcliente AS
  (SELECT
     `c`.`Nombre`    AS `Cliente`,
     `m`.`Nombre`    AS `Mascota`,
     `c`.`Telefono`  AS `Telefono`,
     `c`.`Direccion` AS `Direccion`
   FROM (`bdvironchi`.`cliente` `c`
     JOIN `bdvironchi`.`mascota` `m` ON ((`c`.`id_Cliente` = `m`.`id_Cliente`))));
