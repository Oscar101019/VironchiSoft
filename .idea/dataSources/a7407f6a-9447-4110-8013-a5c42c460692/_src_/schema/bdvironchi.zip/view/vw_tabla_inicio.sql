CREATE VIEW `vw_tabla_inicio` AS
  (SELECT
     `cl`.`Nombre`   AS `Cliente`,
     `m`.`Nombre`    AS `Mascota`,
     `tci`.`TipoCit` AS `TipoCit`,
     `tci`.`Fecha`   AS `Fecha`
   FROM ((`bdvironchi`.`tabla_citas_inicio` `tci`
     JOIN `bdvironchi`.`mascota` `m` ON ((`m`.`id_Mascota` = `tci`.`id_Mascota`))) JOIN `bdvironchi`.`cliente` `cl`
       ON ((`cl`.`id_Cliente` = `m`.`id_Cliente`))))